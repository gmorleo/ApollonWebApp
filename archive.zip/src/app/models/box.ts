export interface Box {
  lon_min: any;
  lat_min: any;
  lon_max: any;
  lat_max: any;
}
